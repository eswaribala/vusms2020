package com.virtusa.bankdemo.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.virtusa.bankdemo.models.Bank;

public interface BankRepository extends JpaRepository<Bank,Integer>{

}
