package com.virtusa.marketdata.configurations;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.messaging.Processor;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.integration.annotation.Transformer;

import com.vitusa.marketdata.util.MarketDataParser;


@EnableBinding(Processor.class)
public class MarketDataProcessorConfiguration {
	
	//reads from rmq message and writes to rmq after conversion
	@Transformer(inputChannel = Processor.INPUT,outputChannel = Processor.OUTPUT)
	public String transformMessage(String futureData)
	{
		
		//String response=MarketDataParser.parseString(futureData);
			//System.out.println("Processor--->"+response);
		
		
		return futureData;
	}

}
