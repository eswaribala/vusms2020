package com.virtusa.eurekaserverdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaserverdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
