package com.virtusa.kafkaappointmentproducer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KafkaappointmentproducerApplication {

	public static void main(String[] args) {
		SpringApplication.run(KafkaappointmentproducerApplication.class, args);
	}

}
