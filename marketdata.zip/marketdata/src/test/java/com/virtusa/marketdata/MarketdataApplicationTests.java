package com.virtusa.marketdata;
/*
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.util.Assert;
import org.springframework.web.client.RestTemplate;

import com.github.wnameless.json.flattener.JsonFlattener;
import com.github.wnameless.json.unflattener.JsonUnflattener;

import net.minidev.json.JSONObject;
import net.minidev.json.parser.JSONParser;

@SpringBootTest
class MarketdataApplicationTests {

	private RestTemplate restTemplate=new RestTemplate();
	@Test
	void contextLoads() {
		CompletableFuture<String> future = getLIBOR();
		
		assertTrue(future.isDone());
		try {
			System.out.println("Received:"+parseString(future.get()));
		} catch (InterruptedException | ExecutionException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		 try {
			assertNotNull(future.get());
		  } catch (ExecutionException | InterruptedException e) {
			fail("No Exception expected");
		}
		
		
		
	}
	
	@Async
    public CompletableFuture<String> getLIBOR() {
        String url = "https://www.quandl.com/api/v3/datasets/FRED/USDONTD156N.json?api_key=FZzZ6q4zZFFQVaELX-Zs";
        ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET,null,String.class);

        return CompletableFuture.completedFuture(response.getBody());
    }
	  private String parseString(String response)
			{
				JSONParser parser = new JSONParser(); 
				String data="";
				String flattenedJson="";
			  	try {
			  		 
					// Put above JSON content to crunchify.txt file and change path location
					Object obj = parser.parse(response);
					JSONObject jsonObject = (JSONObject) obj;
		 
					// JsonFlattener: A Java utility used to FLATTEN nested JSON objects
					flattenedJson = JsonFlattener.flatten(jsonObject.toString());
					System.out.println("\n=====Simple Flatten===== \n" + flattenedJson);
		 
					Map<String, Object> flattenedJsonMap = JsonFlattener.flattenAsMap(jsonObject.toString());
				 	//data=(String) flattenedJsonMap.get("dataset");   
					flattenedJsonMap.values().stream().forEach(System.out::println);
					//log("\n=====Flatten As Map=====\n" + flattenedJson);
					// We are using Java8 forEach loop. More info: https://crunchify.com/?p=8047
					//flattenedJsonMap.forEach((k, v) -> log(k + " : " + v));
		 
					// Unflatten it back to original JSON
					String nestedJson = JsonUnflattener.unflatten(flattenedJson);
					System.out.println("\n=====Unflatten it back to original JSON===== \n" + nestedJson);
				} catch (Exception e) {
					e.printStackTrace();
				}
			 return flattenedJson;

			}
}
*/