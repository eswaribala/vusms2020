package com.virtusa.customerapidemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomerapidemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomerapidemoApplication.class, args);
	}

}
