package com.virtusa.marketdata.configurations;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.messaging.Processor;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.integration.annotation.Transformer;

import com.google.gson.Gson;
import com.vitusa.marketdata.util.MarketDataParser;


@EnableBinding(Processor.class)
public class MarketDataProcessorConfiguration {
	
	//reads from rmq message and writes to rmq after conversion
	@ServiceActivator(inputChannel = Processor.INPUT,outputChannel = Processor.OUTPUT)
	public String transformMessage(Map<String, Object> futureData)
	{
			//String response=MarketDataParser.parseString(futureData);
		//System.out.println("Processor--->"+futureData);
		futureData.values().stream().forEach(System.out::println);
		List<Object> marketList=futureData.values().stream().collect(Collectors.toList());
		Map<Object,Object> marketData=new HashMap<Object,Object>();
		Object key,value=null;
		try
		{
		for(int i=0;i<marketList.size()-2;i+=2)
		   {
			  key=marketList.get(i);
			  value=marketList.get(i+1);
			//  if(key!=null && value!=null)
			   marketData.put(key, value);
		    }
		}
		catch(NullPointerException exception)
		{
			
		}
		marketData.keySet().stream().forEach(System.out::println);	
		marketData.values().stream().forEach(System.out::println);	
		
		 Gson gsonObj = new Gson();  
		String jsonStr = gsonObj.toJson(marketData);
		System.out.println(jsonStr);
		return jsonStr;
	}

}
