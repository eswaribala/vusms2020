package com.virtusa.bankdemo;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.virtusa.bankdemo.models.Bank;
import com.virtusa.bankdemo.repositories.BankRepository;
import com.virtusa.bankdemo.services.BankService;
@SpringBootTest
public class BankTest {
	@Mock
	private BankRepository bankRepository;	
	@InjectMocks //injecting mock repository
	private BankService bankService=new BankService();	
	@BeforeEach
	public void mockBankInstance()
	{		
		Bank bank=new Bank();
		bank.setBankId(1234);
		bank.setBankName("Citi");
		bank.setAddress("NYC");
		Optional<Bank> optionalInstance=Optional.of(bank);		
		when(bankRepository.findById(1234)).thenReturn(optionalInstance);		
	}
	
	@Test
	@DisplayName("Test to find Bank By Id")
	public void getBankById()
	{
	   assertNotNull(this.bankService.getBankById(1234));
	   assertEquals("NYC",this.bankService.getBankById(1234).getAddress());
	}
	
	
	
	

	/*
	@ParameterizedTest
	@CsvFileSource(resources = "/bank.csv",numLinesToSkip = 1)
	public void bankDataNotNull(int bankNo,String bankName, String address)
	{
		//Bank Name >= 3 chars
		assertTrue(bankName.length()>=3);
		//Address should be NYC
		assertEquals("NYC", address);
				
	}
	*/
	
}
