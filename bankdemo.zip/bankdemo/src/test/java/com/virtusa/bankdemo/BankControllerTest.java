package com.virtusa.bankdemo;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.hamcrest.Matchers;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import com.virtusa.bankdemo.models.Bank;
import com.virtusa.bankdemo.services.BankService;

@WebMvcTest
public class BankControllerTest {

	@Autowired
	private MockMvc mockMvc;
	
	@MockBean
	private BankService bankService;
	
	@Test
	public void getBanksTest() throws Exception
	{
		Mockito.when(bankService.getAllBanks()).thenReturn(getBanks());
		mockMvc.perform(get("/banks")).andExpect(status().isOk())
		.andExpect(jsonPath("$", Matchers.hasSize(100)))
		.andExpect(jsonPath("$[0].bankName", Matchers.startsWith("Bank")));
		
	}
	
	
	private List<Bank> getBanks()
	{
		List<Bank> bankList=new ArrayList<Bank>();
		Bank bank=null;
		for(int i=0;i<100;i++)
		{
			bank=new Bank();
			bank.setBankId(new Random().nextInt(1000));
			bank.setBankName("Bank"+new Random().nextInt(1000));
			bank.setAddress("address"+new Random().nextInt(1000));
			bankList.add(bank);	
		}
		
		return bankList;
	}
	

}
