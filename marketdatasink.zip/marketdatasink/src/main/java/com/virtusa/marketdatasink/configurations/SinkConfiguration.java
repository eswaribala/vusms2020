package com.virtusa.marketdatasink.configurations;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.cloud.stream.messaging.Sink;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableBinding(Sink.class)
public class SinkConfiguration {
	private static final Logger logger = LoggerFactory.getLogger(SinkConfiguration.class);
	@StreamListener(Sink.INPUT)
	public void saveBeneficiary(String marketData) {
		//marketData.values().stream().forEach(System.out::println);
		//logger.info("MarketData===>"+marketData);
		System.out.println("MarketData===>"+marketData);
	}

}
