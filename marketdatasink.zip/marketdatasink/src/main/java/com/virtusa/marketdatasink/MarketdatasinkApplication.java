package com.virtusa.marketdatasink;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MarketdatasinkApplication {

	public static void main(String[] args) {
		SpringApplication.run(MarketdatasinkApplication.class, args);
	}

}
