package com.virtusa.marketdata.configurations;

import java.util.concurrent.CompletableFuture;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.messaging.Source;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.integration.core.MessageSource;
import org.springframework.integration.annotation.InboundChannelAdapter;
import org.springframework.integration.annotation.Poller;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.scheduling.annotation.Async;
import org.springframework.web.client.RestTemplate;
import com.virtusa.marketdata.util.MarketDataGenerator;


@Configuration
@EnableBinding(Source.class)
public class MarketDataConfigurer {
	private static final Logger logger = LoggerFactory.getLogger(MarketDataConfigurer.class);
	@Bean
	@InboundChannelAdapter(value = Source.OUTPUT, poller = @Poller(fixedDelay = "1000", 
	maxMessagesPerPoll = "1"))

	public MessageSource<String>  sendMessage()
	{	
		//send market data
		//lambda expression
		//functional interface (java 8)
		//logger.info(new MarketDataGenerator().getLIBOR());
		return ()->MessageBuilder.withPayload("2020-06-25:78.90").build();
	}
	
	
	
	
	
}
