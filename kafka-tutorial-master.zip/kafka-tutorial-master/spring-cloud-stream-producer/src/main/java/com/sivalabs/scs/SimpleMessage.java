package com.sivalabs.scs;

import lombok.Data;

@Data
public class SimpleMessage {
    private String data;
}
