package com.sivalabs.scs;

import lombok.Data;

@Data
public class IncomingMessage {
    private String data;
}
