package com.virtusa.bankdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(BankdemoApplication.class, args);
	}

}
