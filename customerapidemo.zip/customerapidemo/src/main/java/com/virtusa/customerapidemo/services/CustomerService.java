package com.virtusa.customerapidemo.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.virtusa.customerapidemo.models.Customer;
import com.virtusa.customerapidemo.repositories.CustomerRepository;


@Service
public class CustomerService {
	@Autowired
	private CustomerRepository customerRepo;
	
	//insert the customer
	public Customer saveCustomer(Customer customer)
	{
		return this.customerRepo.save(customer);
	}
	
	//findall
	public List<Customer> getAllCustomers()
	{
		return this.customerRepo.findAll();
	}
	
	
	public Customer getCustomerById(long customerId)
	{
		return this.customerRepo.findById(customerId).orElse(null);
	}
	 
	//delete the customer
	
	//select where by customerId
		public void deleteCustomerById(long customerId)
		{
		     this.customerRepo.deleteById(customerId);
		}
	
		//update the customer
		public Customer updateCustomer(Customer customer)
		{
			return this.customerRepo.save(customer);
		}
		
		public List<Customer> findPaginated(int pageNo, int pageSize) {

	        Pageable paging = PageRequest.of(pageNo, pageSize);
	        Page<Customer> pagedResult = customerRepo.findAll(paging);

	        return pagedResult.toList();
	    }

}
