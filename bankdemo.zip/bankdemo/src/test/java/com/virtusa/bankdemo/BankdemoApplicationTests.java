package com.virtusa.bankdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
