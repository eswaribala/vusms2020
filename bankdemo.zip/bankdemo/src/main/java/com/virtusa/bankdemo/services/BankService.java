package com.virtusa.bankdemo.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.virtusa.bankdemo.models.Bank;
import com.virtusa.bankdemo.repositories.BankRepository;

@Service
public class BankService {
	@Autowired
	private BankRepository bankRepository;
    //insert
	public Bank addBank(Bank bank)
	{
		return this.bankRepository.save(bank);
	}
	
	
	public List<Bank>  getAllBanks()
	{
		return this.bankRepository.findAll();
	}
 	
	public Bank getBankById(int bankId)
	{
		return this.bankRepository.findById(bankId).orElse(null);
	}
	
	
}
