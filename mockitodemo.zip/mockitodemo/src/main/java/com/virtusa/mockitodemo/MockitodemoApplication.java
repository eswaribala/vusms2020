package com.virtusa.mockitodemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MockitodemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(MockitodemoApplication.class, args);
	}

}
