package com.virtusa.hystrixdashboarddemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HystrixdashboarddemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
